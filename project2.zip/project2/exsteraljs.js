// JavaScript Document


	
	var addn= prompt("What is 7+14");
	switch(addn){
		case "21":
			alert ("Correct! You GO!");
			break;
			
		default:
			alert("Please try again.");
	}

function addnumb(a, b) {
	var addtotal= a +b;
	return addtotal;
}

var addnumbers2= addnumb(7, 14);
alert (addnumbers2);


	